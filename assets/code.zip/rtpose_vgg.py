"""CPM Pytorch Implementation"""

from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.data as data
import torch.utils.model_zoo as model_zoo
from torch.autograd import Variable
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def make_stages(cfg_dict):
    """Builds CPM stages from a dictionary
    Args:
        cfg_dict: a dictionary
    """
    layers = []
    for i in range(len(cfg_dict) - 1):
        one_ = cfg_dict[i]
        for k, v in one_.items():
            if 'pool' in k:
                layers += [nn.MaxPool2d(kernel_size=v[0], stride=v[1],
                                        padding=v[2])]
            else:
                conv2d = nn.Conv2d(in_channels=v[0], out_channels=v[1],
                                   kernel_size=v[2], stride=v[3],
                                   padding=v[4])
                layers += [conv2d, nn.ReLU(inplace=True)]
    one_ = list(cfg_dict[-1].keys())
    k = one_[0]
    v = cfg_dict[-1][k]
    conv2d = nn.Conv2d(in_channels=v[0], out_channels=v[1],
                       kernel_size=v[2], stride=v[3], padding=v[4])
    layers += [conv2d]
    return nn.Sequential(*layers)


def make_vgg19_block(block):
    """Builds a vgg19 block from a dictionary
    Args:
        block: a dictionary
    """
    layers = []
    for i in range(len(block)):
        one_ = block[i]
        for k, v in one_.items():
            if 'pool' in k:
                #layers += [nn.ReLu(inplace=True)]
                #layers += [nn.MaxPool2d(kernel_size=v[0], stride=v[1], padding=v[2])]
                print('This net has no pooling')
            else:
                conv2d = nn.Conv2d(in_channels=v[0], out_channels=v[1],
                                   kernel_size=v[2], stride=v[3],
                                   padding=v[4])
                layers += [conv2d, nn.ReLU(inplace=True)]
    return nn.Sequential(*layers)



def get_model(trunk='vgg19'):
    """Creates the whole CPM model
    Args:
        trunk: string, 'vgg19' or 'mobilenet'
    Returns: Module, the defined model
    """
    blocks = {}
    # block0 is the preprocessing stage
    if trunk == 'vgg19':
        block0 = [{'conv1_1': [3, 64, 3, 1, 1]},
                  {'conv1_2': [64, 64, 3, 1, 1]},
                  {'pool1_stage1': [2, 2, 0]},
                  {'conv2_1': [64, 128, 3, 1, 1]},
                  {'conv2_2': [128, 128, 3, 1, 1]},
                  {'pool2_stage1': [2, 2, 0]},
                  {'conv3_1': [128, 256, 3, 1, 1]},
                  {'conv3_2': [256, 256, 3, 1, 1]},
                  {'conv3_3': [256, 256, 3, 1, 1]},
                  {'conv3_4': [256, 256, 3, 1, 1]},
                  {'pool3_stage1': [2, 2, 0]},
                  {'conv4_1': [256, 512, 3, 1, 1]},
                  {'conv4_2': [512, 512, 3, 1, 1]},
                  {'conv4_3_CPM': [512, 256, 3, 1, 1]},
                  {'conv4_4_CPM': [256, 128, 3, 1, 1]}]

    elif trunk == 'mobilenet':
        block0 = [{'conv_bn': [3, 32, 2]},  # out: 3, 32, 184, 184
                  {'conv_dw1': [32, 64, 1]},  # out: 32, 64, 184, 184
                  {'conv_dw2': [64, 128, 2]},  # out: 64, 128, 92, 92
                  {'conv_dw3': [128, 128, 1]},  # out: 128, 256, 92, 92
                  {'conv_dw4': [128, 256, 2]},  # out: 256, 256, 46, 46
                  {'conv4_3_CPM': [256, 256, 1, 3, 1]},
                  {'conv4_4_CPM': [256, 128, 1, 3, 1]}]

    # Stage 1
    blocks['block1_1'] = [{'conv5_1_CPM_L1': [128, 128, 3, 1, 1]},
                          {'conv5_2_CPM_L1': [128, 128, 3, 1, 1]},
                          {'conv5_3_CPM_L1': [128, 128, 3, 1, 1]},
                          {'conv5_4_CPM_L1': [128, 512, 1, 1, 0]},
                          {'conv5_5_CPM_L1': [512, 8, 1, 1, 0]}]

    blocks['block1_2'] = [{'conv5_1_CPM_L1': [128, 128, 3, 1, 1]},
                          {'conv5_2_CPM_L1': [128, 128, 3, 1, 1]},
                          {'conv5_3_CPM_L1': [128, 128, 3, 1, 1]},
                          {'conv5_4_CPM_L1': [128, 512, 1, 1, 0]},
                          {'conv5_5_CPM_L1': [512, 8, 1, 1, 0]}]

    models = {}

    if trunk == 'vgg19':
        print("Bulding VGG19")
        models['block0'] = make_vgg19_block(block0)

    for k, v in blocks.items():
        models[k] = make_stages(list(v))

    class rtpose_model(nn.Module):
        def __init__(self, model_dict):
            super(rtpose_model, self).__init__()
            self.model0 = model_dict['block0']
            self.model1_1 = model_dict['block1_1']
            self.model1_2 = model_dict['block1_2']

            self._initialize_weights_norm()

        def forward(self, x):

            out1 = self.model0(x)
            out1_1 = self.model1_1(out1)
            out1_2 = self.model1_2(out1)
            height, width = out1_1.shape[-2], out1_1.shape[-1]
            heatmap_max = torch.max(torch.max(out1_1, dim=2, keepdim=True)[0], dim=3, keepdim=True)[0]
            heatmap_min = torch.min(torch.min(out1_1, dim=2, keepdim=True)[0], dim=3, keepdim=True)[0]
            heatmap = (out1_1 - heatmap_min) / (heatmap_max - heatmap_min)
            heatmap = heatmap / torch.sum(heatmap, dim=(2,3), keepdim=True)
            x = torch.sum(heatmap * (torch.arange(width).to(device)), dim=(2,3)).unsqueeze(-1)
            y = torch.sum(heatmap * (torch.arange(height).unsqueeze(-1).to(device)), dim=(2,3)).unsqueeze(-1)
            z = torch.sum(heatmap * out1_2, dim=(2,3)).unsqueeze(-1)
            keypoints = torch.cat(x,y,z, dim=2)
            relative_matrix = torch.cat(torch.sum((keypoints - keypoints[:,0,:].unsqueeze(1))*(keypoints - keypoints[:,0,:].unsqueeze(1)), dim=2, keepdim=True),
                                        torch.sum((keypoints - keypoints[:,1,:].unsqueeze(1))*(keypoints - keypoints[:,1,:].unsqueeze(1)), dim=2, keepdim=True),
                                        torch.sum((keypoints - keypoints[:,2,:].unsqueeze(1))*(keypoints - keypoints[:,2,:].unsqueeze(1)), dim=2, keepdim=True),
                                        torch.sum((keypoints - keypoints[:,3,:].unsqueeze(1))*(keypoints - keypoints[:,3,:].unsqueeze(1)), dim=2, keepdim=True),
                                        torch.sum((keypoints - keypoints[:,4,:].unsqueeze(1))*(keypoints - keypoints[:,4,:].unsqueeze(1)), dim=2, keepdim=True),
                                        torch.sum((keypoints - keypoints[:,5,:].unsqueeze(1))*(keypoints - keypoints[:,5,:].unsqueeze(1)), dim=2, keepdim=True),
                                        torch.sum((keypoints - keypoints[:,6,:].unsqueeze(1))*(keypoints - keypoints[:,6,:].unsqueeze(1)), dim=2, keepdim=True),
                                        torch.sum((keypoints - keypoints[:,7,:].unsqueeze(1))*(keypoints - keypoints[:,7,:].unsqueeze(1)), dim=2, keepdim=True), dim=2)
            relative_matrix = relative_matrix / torch.sum(relative_matrix)

            return keypoints, relative_matrix

        def _initialize_weights_norm(self):

            for m in self.modules():
                if isinstance(m, nn.Conv2d):
                    init.normal_(m.weight, std=0.01)
                    if m.bias is not None:  # mobilenet conv2d doesn't add bias
                        init.constant_(m.bias, 0.0)

            # last layer of these block don't have Relu
            init.normal_(self.model1_1[8].weight, std=0.01)
            init.normal_(self.model1_2[8].weight, std=0.01)

    model = rtpose_model(models)
    return model


"""Load pretrained model on Imagenet
:param model, the PyTorch nn.Module which will train.
:param model_path, the directory which load the pretrained model, will download one if not have.
:param trunk, the feature extractor network of model.               
"""


def use_vgg(model):

    url = 'https://download.pytorch.org/models/vgg19-dcbb9e9d.pth'
    vgg_state_dict = model_zoo.load_url(url)
    vgg_keys = vgg_state_dict.keys()

    # load weights of vgg
    weights_load = {}
    # weight+bias,weight+bias.....(repeat 10 times)
    for i in range(20):
        weights_load[list(model.state_dict().keys())[i]
                     ] = vgg_state_dict[list(vgg_keys)[i]]

    state = model.state_dict()
    state.update(weights_load)
    model.load_state_dict(state)
    print('load imagenet pretrained model')
